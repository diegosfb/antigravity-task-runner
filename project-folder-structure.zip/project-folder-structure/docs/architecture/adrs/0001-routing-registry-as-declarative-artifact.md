# ADR-0001: Routing registry is a declarative artifact interpreted by the orchestrator, not an executable file

## Status
Accepted
**Date**: 2026-08-14
**Deciders**: dsfb-sdlc maintainer

## Context
The dsfb-sdlc v2 library ships `routing-registry.yaml`, which maps user requests to the agent that should handle them. A recurring question is *how the registry is actually used at runtime* - specifically whether anything in the package reads it and dispatches automatically.

It does not. The package contains no parser, dispatcher, or validation step that consumes the YAML. The registry describes routing; it does not implement it. This ADR records that design choice explicitly so the boundary between "specification" and "execution" is not misread, and so future contributors know which component is responsible for turning the registry into behavior.

The registry has four parts:
- `workflow` - phase order and artifact handoffs (who produces what, and who it goes to); the source-of-truth sequence.
- `targets.agents` - every agent with its phase, on-disk file path, and (for subagents) parent and active/dormant status.
- `routes` - trigger keywords mapped to a target agent (e.g. "deploy, ci/cd, rollback" -> deployment-agent).
- `matching` / `tie_breakers` - how to choose when several routes overlap.

## Decision Drivers
- Keep routing logic out of `sdlc-orchestrator.md` so agents can be added or changed by editing YAML, not prose.
- Make the workflow sequence and handoffs inspectable and version-controllable as data.
- Avoid coupling the library to any single runtime or framework.
- Be honest about what the package does and does not execute on its own.

## Considered Options

### Option 1: Declarative registry, interpreted by the orchestrator agent (chosen)
- **Pros**: Framework-agnostic; single source of truth for routing; edited as data; the orchestrator (or a human) is the interpreter, so the same registry works in Claude Code, a custom dispatcher, or manual lookup.
- **Cons**: Nothing enforces consistency between the registry and the files on disk; requires an orchestrator or harness to become behavior.

### Option 2: Hardcode routing inside sdlc-orchestrator.md
- **Pros**: One fewer file; routing and dispatcher live together.
- **Cons**: Every agent addition edits the orchestrator prose; routing is no longer inspectable as data; merge-prone and error-prone.

### Option 3: Ship an executable dispatcher that reads the registry
- **Pros**: Registry becomes directly actionable with no orchestrator interpretation.
- **Cons**: Couples the library to a runtime/language; more to maintain; premature before the execution environment is fixed.

## Decision
Keep the routing registry as a **declarative artifact** that is **interpreted by whatever component is pointed at it** - primarily the `sdlc-orchestrator` agent, secondarily a host harness, and at minimum a human doing manual lookup. The package does not include a parser or dispatcher; the registry is documentation-of-record for routing, and the orchestrator is the piece that turns it into behavior.

## Rationale
The registry's value is that adding or changing an agent means editing YAML and never touching orchestrator prose - the registry's own `registration` section states this contract. That value survives regardless of runtime, so binding the registry to a specific executable dispatcher would trade portability for automation the library does not yet need. Being explicit that the file is interpreted (not executed) prevents the failure mode of assuming dispatch "just happens."

## Intended runtime flow
```text
User request
   -> sdlc-orchestrator reads routing-registry.yaml
   -> matches request against `routes` triggers -> picks target agent
   -> applies `tie_breakers` if multiple routes match
   -> loads the agent's .md via the path in `targets.agents`
   -> agent runs; developer-agent additionally checks each dormant
      subagent's `activates_when` before fan-out
   -> artifact handoff follows `workflow.artifacts` to the next agent
```

## Consumers (who turns the registry into behavior)
- **sdlc-orchestrator agent** - the intended primary consumer. Loads the registry, matches intent, dispatches. Routing logic stays out of its prose by design.
- **Host harness / framework** - if the agents are loaded into Claude Code, an MCP-style tool layer, or a custom dispatcher, that layer parses the YAML and routes. No such parser is shipped in this package.
- **Human** - at minimum, the registry is a lookup table: request -> route -> target agent file.

## Consequences

### Positive
- Framework-agnostic: the same registry drives an agent orchestrator, a harness, or manual routing.
- Adding an agent is a data edit (register + add route), not a prose edit to the orchestrator.
- Workflow order and handoffs are inspectable and diffable as structured data.

### Negative
- The package does not route anything by itself; an orchestrator or harness is required to make it behave.
- Nothing shipped validates that `targets.agents` paths exist or that routes point to registered targets - the registry can silently drift from the files on disk.

### Neutral
- The registry doubles as human-readable documentation of the workflow.

### Risks
- **Drift** between the registry and the agent files (renamed or moved agent, unregistered route) with no automatic detection.
  - **Mitigation**: add a `validate-registry.py` that asserts every `targets.agents` path exists and every route resolves to a registered target; run it in CI or pre-commit.
- **Missing v2 orchestrator**: the v1 `sdlc-orchestrator` was merged out and no v2 replacement is shipped, so the intended primary consumer is currently absent.
  - **Mitigation**: author a v2 `sdlc-orchestrator.md` that explicitly loads and follows this registry.

## Implementation Notes
- Two follow-ups close the gap between "documented" and "enforced/executed":
  1. `validate-registry.py` - path-existence and route-resolution checks against the registry.
  2. v2 `sdlc-orchestrator.md` - instructs the orchestrator to load and follow `routing-registry.yaml`; this is the component that converts the registry from specification into behavior.
- Until (2) exists, the registry is used by a host harness or by manual lookup.

## Related Decisions
- (planned) ADR-0002: sdlc-orchestrator v2 dispatch semantics
- (planned) ADR-0003: dormant subagent activation (`activates_when`) evaluation

## References
- `routing-registry.yaml` (this package)
- `README.md`, `INDEX.md`, `MERGE-STATUS.md` (this package)
- Workflow source of truth: `workflow-design/agent-orchestrated-sdlc.mmd`
