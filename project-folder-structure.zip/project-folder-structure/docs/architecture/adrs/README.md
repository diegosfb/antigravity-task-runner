# Architecture Decision Records

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| 0001 | Routing registry is a declarative artifact interpreted by the orchestrator | Accepted | 2026-08-14 |
