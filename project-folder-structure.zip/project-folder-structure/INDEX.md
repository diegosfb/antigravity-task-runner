# dsfb-sdlc v2 — consolidated package

Everything needed to run the agent-orchestrated SDLC workflow, and nothing that isn't. Off-stack and unused v1 material has been left out (see docs/Backup/DISPOSITION.md for what and why).

## Contents

| Folder | What's in it |
|---|---|
| `sdlc-orchestrator` (in .agents/agents/) | Entry point: reads the registry, classifies intent, dispatches, sequences handoffs. Start here for orchestrated use. |
| `USAGE.md` | How to run the library - orchestrated (Option A) or direct (Option B). Read this first. |
| `PROJECT-STRUCTURE.md` | Scaffolding & structure: full package tree, which agent reads/writes each `docs/` folder, artifact flow, and how to scaffold a new project workspace. |
| `validate-registry.py` | Checks the registry against files on disk (paths exist, routes and artifact producers are registered). |
| `.agents/agents/` | 14 top-level agents: the 10 core (sdlc-orchestrator + the 9 workflow agents) with their subagents (8 developer: 3 active/5 dormant; 6 architect design: 1 active/5 dormant); the optional quality gates `llm-judge-agent` and `spec-validation-agent` (+2 subagents); and the off-workflow `consultant-agent` (+8 subagents) and `obsidian-vault-agent`. Merged v1 content is carried as agent-local references. ba/product/planner/test carry empty `subagents/` placeholders for future splits. |
| `.agents/skills/` | The 67 skills attached to agents (includes the former extendedLib UX pieces `accessibility`, `accessibility-runtime-tester`, `ui-designer`, `ui-design-system`, `ux-researcher-designer`). Every `skills/<x>` reference resolves here. |
| `.agents/agents/consultant-agent/subagents/` | Consultant subagents, including the platform SMEs that inform but don't build: `gcp-sme` (core stack, always available), `doc-generator` (utility), and dormant `aws-sme` / `azure-sme` / `snowflake-sme` (load per engagement). Consulted by architect-agent and data-developer, and directly invokable. |
| `workflow-design/` | The source-of-truth workflow: diagram (.pptx / .mmd) and the roles-and-artifacts brief (.docx). |
| `routing-registry.yaml` | Workflow order, artifact handoffs, trigger routes, and active/dormant subagent status. |
| `docs/architecture/` | The architect-agent's output home: `architecture.md` (solution architecture, per the agent's `references/architecture-template.md`), `development_guidelines.md` (optional per-project input — binding guardrails for architectural decisions), and `adrs/` (decision records; ADR-0001 documents how the routing registry is used). |
| `docs/Backup/DISPOSITION.md` | Keep / merge / subagent / consulting / park / drop call for every v1 agent and skill. |
| `docs/Backup/MERGE-STATUS.md` | Per-merge execution ledger: what each v1 agent became and how its content was carried. |
| `docs/Backup/README.md` | How the merges were executed. |

## The workflow
Product (produces the PRD at `docs/project_description/PRD.md`) → BA → Architect (data-architect active, +dormant mobile/iot/embedded/blockchain/databricks design specialists; produces `docs/architecture/architecture.md` + ADRs + technical tasks) → UX → Project planner → **Task backlog** → Developer (FE/BE/Data, +dormant mobile/iot/embedded/blockchain/databricks builders) → Test → Code review → Deployment → Live.
Loops: tests-fail and changes-requested return to Developer; production feedback returns to Product.
Optional gates (advisory, never replace the test/review gates; automation per project via `ADLC_workflow_settings.json`):
- `llm-judge-agent` — after architecture, solutioning, or implementation, a DIFFERENT LLM judges the artifact against rubrics (report to `docs/reviews/`). `llm_judge.trigger_mode`.
- `spec-validation-agent` — spec-conformance (spec-drift-checker) and spec-aware adversarial security (spec-red-team) against `docs/specs/`. `spec_validation.drift_check_mode` / `red_team_mode`.

## Off-workflow
`obsidian-vault-agent` — an optional **knowledge recorder**: as the design progresses it mirrors the artifacts (PRD, specs, ADRs, architecture, backlog/issues, estimation, UX, reviews, decisions, plans, implementation notes, workarounds, test cases) into an Obsidian vault as a linked graph, symlinking the canonical `docs/` files so nothing is duplicated, and logs each agent's actions. Read-only toward the project; enabled and pointed at a vault via `ADLC_workflow_settings.json` (`obsidian_vault`).

`consultant-agent` — an ad-hoc **dispatcher** for one-off consultations (AI tooling, research, decks/spreadsheets, C-suite advice, de-AI-ing text via the `humanizer` skill), routing to consultant subagents, advisory skills, and the platform SMEs in `.agents/agents/consultant-agent/subagents/`. It is NOT a workflow stage and writes nothing into `docs/` handoffs; every consultant it fronts is also invokable directly.

## Start here
`.agents/agents/` + `routing-registry.yaml`. Point your orchestrator at the registry; it routes by workflow phase first, specialty second.

## Not included (recover from the original zip if scope changes)
Dropped off-stack agents' standalone forms (blockchain/embedded/iot/mobile/databricks now live as dormant subagents instead), the ML/DS skill track (data-scientist, senior-ml-engineer, mlops-pipeline, etc.), and duplicated/unreferenced skills. All catalogued in docs/Backup/DISPOSITION.md.
