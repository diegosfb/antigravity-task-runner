# SDLC Orchestrator

> Source contract: [`sdlc-orchestrator.md`](../../../agents/sdlc-orchestrator/sdlc-orchestrator.md). The source contract is authoritative if this summary and the contract differ.

## What it does

Entry-point orchestrator for the dsfb-sdlc v2 library. Reads the user's intent, consults routing-registry.yaml, and dispatches the correct workflow agent(s), then sequences artifact handoffs along the Project Description → Product → BA → Architect → UX → Project Planner → Backlog → Developer → Spec Validation → Test → Documentation → Code Review → Deployment workflow. Start here unless you already know the exact specialist you need.

## How it interacts with other agents

- **Role:** `orchestrator`.

- **Declared interaction points:** `product-agent`, `ba-agent`, `architect-agent`, `ux-agent`, `project-planner-agent`, `developer-agent`, `spec-validation-agent`, `test-agent`, `documentation-agent`, `code-review-agent`, `deployment-agent`. The source contract defines the trigger, evidence, and handoff direction for each interaction.

## Agent Page Diagram

```mermaid
flowchart LR
    subgraph inputs["Inputs"]
        projectDescription["Required: Project Description"]
    end
    sdlcOrchestrator["SDLC Orchestrator Agent"]
    delegation["Output: Delegation to Appropriate Agent(s)"]

    inputs --> sdlcOrchestrator --> delegation
```

## Input artifacts

| Artifact | Requirement | Type | Purpose |
|---|---|---|---|
| `request` | Required | `text_or_structured_data` | User intent, scope, constraints, and authorization. |
| `routing_registry` | Required | `file` | Canonical targets, triggers, paths, and handoffs. |
| `workflow_configuration` | Required | `file` | Approval, validation, security, and automation settings. |

## Output artifacts

| Artifact | Type | Purpose |
|---|---|---|
| `routing_decision` | `structured_data` | Selected agent or workflow and expected artifact handoff. |
| `workflow_state` | `structured_data` | Stage status, approvals, blockers, and next owner. |
| `workflow_result` | `structured_data` | Validated final result for the authorized workflow boundary. |

## Artifact locations

No fixed repository output path is declared. Artifacts are returned through the invoking workflow, existing branch or pull request, configured backlog, CI/CD system, or another location explicitly supplied at runtime.

## Usage notes

- Invoke this agent only within the scope and activation rules defined in [`sdlc-orchestrator.md`](../../../agents/sdlc-orchestrator/sdlc-orchestrator.md).
- Preserve artifact traceability across handoffs; do not substitute summaries for required source evidence.
- Follow repository approval, security, validation, and failure-routing rules before declaring the work complete.

## Documentation source

This page is synchronized from [the canonical agent contract](../../../agents/sdlc-orchestrator/sdlc-orchestrator.md) and its companion README. Update the canonical contract first when behavior changes.
